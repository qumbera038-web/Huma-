import React, { useState } from "react";
import { UserAccount, StoreSettings, Branch, Product, Invoice, Customer } from "../../types";
import { 
  Crown, 
  Building2, 
  TrendingUp, 
  DollarSign, 
  Users, 
  Package, 
  ShieldCheck, 
  Video, 
  Lock, 
  Unlock, 
  ArrowUpRight, 
  ArrowDownLeft, 
  RefreshCw, 
  BarChart3, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  ChevronRight,
  Eye,
  FileText,
  Clock,
  Layers,
  ShoppingBag
} from "lucide-react";

interface SuperAdminDashboardProps {
  activeUser: UserAccount;
  users: UserAccount[];
  branches: Branch[];
  products: Product[];
  invoices: Invoice[];
  customers: Customer[];
  settings: StoreSettings;
  onSwitchBranch: (branchId: string) => void;
  onNavigateTab: (tab: any) => void;
  onUpdateUsers: (updatedUsers: UserAccount[]) => void;
  onUpdateBranches: (updatedBranches: Branch[]) => void;
}

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({
  activeUser,
  users,
  branches,
  products,
  invoices,
  customers,
  settings,
  onSwitchBranch,
  onNavigateTab,
  onUpdateUsers,
  onUpdateBranches,
}) => {
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>("all");
  const [lockedBranchIds, setLockedBranchIds] = useState<string[]>([]);
  const [showManagerModal, setShowManagerModal] = useState<Branch | null>(null);
  const [selectedNewManagerId, setSelectedNewManagerId] = useState<string>("");

  // Calculate high-level financial metrics across all branches
  const activeInvoices = (invoices || []).filter((i) => i.status !== "cancelled");
  const totalGlobalRevenue = activeInvoices.reduce((sum, inv) => sum + inv.grandTotal, 0);
  const totalGlobalPaid = activeInvoices.reduce((sum, inv) => sum + inv.amountPaid, 0);
  const totalGlobalUdhaar = activeInvoices.reduce((sum, inv) => sum + inv.balanceDue, 0);
  
  // Calculate total inventory valuation
  const totalInventoryValuation = (products || []).reduce(
    (sum, p) => sum + (p.stock || 0) * (p.retailPrice || 0),
    0
  );

  // Filter invoices by branch
  const getBranchInvoices = (branchId: string) =>
    activeInvoices.filter((i) => i.branchName?.toLowerCase().includes(branchId === "branch-2" ? "asad" : branchId === "branch-3" ? "abbas" : "main") || i.branchName === (branches || []).find(b => b.id === branchId)?.name);

  // Filter products count per branch
  const getBranchLowStockCount = (branchId: string) => {
    return (products || []).filter((p) => {
      const stock = branchId === "branch-1" ? p.stockBranch1 : branchId === "branch-2" ? p.stockBranch2 : p.stockBranch3;
      return (stock ?? p.stock) <= (p.minStock || 5);
    }).length;
  };

  const toggleLockBranch = (branchId: string) => {
    if (lockedBranchIds.includes(branchId)) {
      setLockedBranchIds(lockedBranchIds.filter((id) => id !== branchId));
    } else {
      setLockedBranchIds([...lockedBranchIds, branchId]);
    }
  };

  const handleChangeManager = (branch: Branch) => {
    if (!selectedNewManagerId) return;
    const managerUser = users.find((u) => u.id === selectedNewManagerId);
    if (!managerUser) return;

    const updatedBranches = branches.map((b) => {
      if (b.id === branch.id) {
        return { ...b, managerName: managerUser.name };
      }
      return b;
    });

    onUpdateBranches(updatedBranches);
    setShowManagerModal(null);
  };

  return (
    <div className="p-4 sm:p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-sans">
      {/* Super Admin Executive Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 border border-indigo-500/30 p-5 rounded-3xl shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-4 z-10">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30 ring-2 ring-white/20 shrink-0">
            <Crown className="w-7 h-7 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-extrabold text-white tracking-tight">
                Super Admin Executive HQ Command Center
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-400/20 text-amber-300 border border-amber-400/40 uppercase tracking-wider flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-amber-400" />
                <span>Haider Ali (Owner View)</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Global control & multi-branch oversight for Main HQ, Asad Sanitary (Branch 2) & Abbas Sanitary (Branch 3)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 z-10 flex-wrap">
          <button
            onClick={() => onNavigateTab("reports")}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-indigo-600/30"
          >
            <BarChart3 className="w-4 h-4" />
            <span>Detailed AI Reports</span>
          </button>
          <button
            onClick={() => onNavigateTab("branches")}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition flex items-center gap-2"
          >
            <Building2 className="w-4 h-4 text-blue-400" />
            <span>Manage All 3 Branches</span>
          </button>
        </div>
      </div>

      {/* Global Financial KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Global Revenue */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative overflow-hidden group hover:border-emerald-500/40 transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Sales Revenue (3 Branches)</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-400 font-mono tracking-tight">
            {settings.currencySymbol} {totalGlobalRevenue.toLocaleString()}
          </p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Collected Cash: {settings.currencySymbol} {totalGlobalPaid.toLocaleString()}</span>
            <span className="text-emerald-400 font-bold">{activeInvoices.length} Bills</span>
          </div>
        </div>

        {/* Card 2: Total Receivables / Udhaar */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative overflow-hidden group hover:border-amber-500/40 transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Udhaar / Receivables</span>
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-400 font-mono tracking-tight">
            {settings.currencySymbol} {totalGlobalUdhaar.toLocaleString()}
          </p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Pending across {customers.length} Accounts</span>
            <span className="text-amber-400 font-bold">Khata Active</span>
          </div>
        </div>

        {/* Card 3: Total Stock Valuation */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative overflow-hidden group hover:border-blue-500/40 transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Inventory Valuation</span>
            <div className="w-9 h-9 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <Package className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-blue-400 font-mono tracking-tight">
            {settings.currencySymbol} {totalInventoryValuation.toLocaleString()}
          </p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>Total Catalog Products</span>
            <span className="text-blue-400 font-bold">{products.length} Items</span>
          </div>
        </div>

        {/* Card 4: Staff & Active Managers */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative overflow-hidden group hover:border-indigo-500/40 transition">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Active Staff & Cashiers</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-indigo-300 font-mono tracking-tight">
            {users.length} Active Users
          </p>
          <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
            <span>3 Branch Managers</span>
            <span className="text-indigo-400 font-bold">All Logged In</span>
          </div>
        </div>
      </div>

      {/* 3 Live Branch Executive Control Grid */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-extrabold text-white flex items-center gap-2">
            <Building2 className="w-5 h-5 text-indigo-400" />
            <span>3 Branch Live Command & Terminal Control</span>
          </h3>
          <span className="text-xs text-slate-400 font-mono">
            Click "Switch View" to inspect any branch terminal directly
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {branches.map((branch) => {
            const branchInvoices = getBranchInvoices(branch.id);
            const branchSales = branchInvoices.reduce((s, i) => s + i.grandTotal, 0);
            const lowStockCount = getBranchLowStockCount(branch.id);
            const isLocked = lockedBranchIds.includes(branch.id);
            const manager = users.find((u) => u.branchId === branch.id && u.role === "manager");

            return (
              <div
                key={branch.id}
                className={`bg-slate-900 border rounded-3xl p-5 shadow-2xl relative flex flex-col justify-between transition ${
                  isLocked ? "border-rose-500/50 bg-rose-950/10" : "border-slate-800 hover:border-indigo-500/40"
                }`}
              >
                {/* Branch Header */}
                <div className="space-y-3 pb-4 border-b border-slate-800">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                      {branch.code || branch.id}
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleLockBranch(branch.id)}
                        className={`p-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 ${
                          isLocked
                            ? "bg-rose-600 text-white shadow-md shadow-rose-600/30"
                            : "bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700"
                        }`}
                        title={isLocked ? "Unlock Branch Terminal" : "Lock Branch Terminal"}
                      >
                        {isLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5 text-slate-400" />}
                        <span>{isLocked ? "Locked" : "Lock"}</span>
                      </button>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-extrabold text-slate-100 text-base">{branch.name}</h4>
                    <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                      <span>📍 {branch.address || "Main Market"}</span>
                    </p>
                  </div>
                </div>

                {/* Branch Manager & Cashier Info */}
                <div className="py-4 space-y-3">
                  <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs font-bold text-indigo-300 border border-indigo-500/30">
                        {manager?.name.charAt(0) || "M"}
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block uppercase font-bold">Branch Head / Owner</span>
                        <span className="text-xs font-bold text-slate-200">{manager?.name || branch.managerName}</span>
                      </div>
                    </div>
                    <button
                      onClick={() => setShowManagerModal(branch)}
                      className="text-[10px] text-indigo-400 hover:text-indigo-300 underline font-semibold"
                    >
                      Change
                    </button>
                  </div>

                  {/* Branch Key Metrics */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-500 block">Today's Branch Revenue</span>
                      <span className="font-extrabold text-emerald-400 font-mono">
                        {settings.currencySymbol} {branchSales.toLocaleString()}
                      </span>
                    </div>
                    <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                      <span className="text-[10px] text-slate-500 block">Low Stock Alert</span>
                      <span className={`font-extrabold font-mono ${lowStockCount > 0 ? "text-amber-400" : "text-slate-300"}`}>
                        {lowStockCount} Items Low
                      </span>
                    </div>
                  </div>
                </div>

                {/* Footer Action Buttons */}
                <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
                  <button
                    onClick={() => onSwitchBranch(branch.id)}
                    className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-lg shadow-blue-600/20"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Switch To Branch View</span>
                  </button>
                  <button
                    onClick={() => onNavigateTab("billing")}
                    className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 rounded-xl transition"
                    title="Open Billing Counter"
                  >
                    <ShoppingBag className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* System Security & CCTV Live Feeds Overview */}
      <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <Video className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-slate-100 text-sm flex items-center gap-2">
                <span>9 Live CCTV Camera Security Feeds</span>
                <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-full text-[9px] font-black animate-pulse">
                  LIVE MONITORED
                </span>
              </h3>
              <p className="text-xs text-slate-400">Real-time surveillance across Branch 1 HQ, Branch 2 & Branch 3 counters</p>
            </div>
          </div>
          <button
            onClick={() => onNavigateTab("branches")}
            className="text-xs text-indigo-400 hover:text-indigo-300 font-bold flex items-center gap-1"
          >
            <span>Open All CCTVs</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <div>
                <span className="text-xs font-bold text-slate-200 block">Branch 1 HQ (Main Desk)</span>
                <span className="text-[10px] text-slate-500">3 Cameras Active</span>
              </div>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">1080p HD</span>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <div>
                <span className="text-xs font-bold text-slate-200 block">Branch 2 (Asad Sanitary)</span>
                <span className="text-[10px] text-slate-500">3 Cameras Active</span>
              </div>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">1080p HD</span>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
              <div>
                <span className="text-xs font-bold text-slate-200 block">Branch 3 (Abbas Sanitary)</span>
                <span className="text-[10px] text-slate-500">3 Cameras Active</span>
              </div>
            </div>
            <span className="text-xs font-mono text-emerald-400 font-bold">1080p HD</span>
          </div>
        </div>
      </div>

      {/* Change Branch Manager Modal */}
      {showManagerModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-indigo-500/40 rounded-3xl max-w-md w-full p-6 shadow-2xl text-slate-200">
            <h3 className="font-bold text-slate-100 text-base mb-2">
              Assign Manager for {showManagerModal.name}
            </h3>
            <p className="text-xs text-slate-400 mb-4">
              Select an authorized manager account to oversee operations at this branch terminal.
            </p>

            <select
              value={selectedNewManagerId}
              onChange={(e) => setSelectedNewManagerId(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 text-slate-100 p-3 rounded-xl text-xs mb-4 font-medium outline-none focus:border-indigo-500"
            >
              <option value="">-- Select Manager Account --</option>
              {users.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name} ({u.role.toUpperCase()}) - {u.branchName || "HQ"}
                </option>
              ))}
            </select>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowManagerModal(null)}
                className="flex-1 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
              >
                Cancel
              </button>
              <button
                onClick={() => handleChangeManager(showManagerModal)}
                className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30"
              >
                Confirm Assignment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
