import React, { useState } from "react";
import { UserAccount, StoreSettings, Branch, Product, Invoice, Customer } from "../../types";
import { 
  Building2, 
  TrendingUp, 
  DollarSign, 
  Package, 
  Users, 
  Receipt, 
  ShoppingBag, 
  AlertTriangle, 
  CheckCircle2, 
  RefreshCw, 
  Clock, 
  MessageSquare, 
  Sparkles, 
  ChevronRight, 
  Send, 
  ShieldCheck,
  Calendar,
  Layers,
  PhoneCall
} from "lucide-react";

interface BranchOwnerDashboardProps {
  activeUser: UserAccount;
  activeBranch: Branch;
  products: Product[];
  invoices: Invoice[];
  customers: Customer[];
  settings: StoreSettings;
  onNavigateTab: (tab: any) => void;
}

export const BranchOwnerDashboard: React.FC<BranchOwnerDashboardProps> = ({
  activeUser,
  activeBranch,
  products,
  invoices,
  customers,
  settings,
  onNavigateTab,
}) => {
  const [stockRefillRequested, setStockRefillRequested] = useState(false);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>("all");

  // Filter invoices strictly for this branch
  const branchInvoices = (invoices || []).filter(
    (i) =>
      i.status !== "cancelled" &&
      (i.branchName === activeBranch.name ||
        i.branchName?.toLowerCase().includes(activeBranch.id === "branch-2" ? "asad" : activeBranch.id === "branch-3" ? "abbas" : "main"))
  );

  const todayBranchRevenue = branchInvoices.reduce((sum, inv) => sum + inv.grandTotal, 0);
  const todayBranchCash = branchInvoices.reduce((sum, inv) => sum + inv.amountPaid, 0);
  const todayBranchUdhaar = branchInvoices.reduce((sum, inv) => sum + inv.balanceDue, 0);

  // Branch Low Stock items
  const branchLowStockItems = (products || []).filter((p) => {
    const stock = activeBranch.id === "branch-1" ? p.stockBranch1 : activeBranch.id === "branch-2" ? p.stockBranch2 : p.stockBranch3;
    return (stock ?? p.stock) <= (p.minStock || 5);
  });

  const handleRequestHQRefill = () => {
    setStockRefillRequested(true);
    setTimeout(() => {
      setStockRefillRequested(false);
    }, 4000);
  };

  return (
    <div className="p-4 sm:p-6 max-w-[1700px] mx-auto space-y-6 text-slate-100 font-sans">
      {/* Branch Head Top Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 border border-blue-500/30 p-5 rounded-3xl shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center gap-4 z-10">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/30 ring-2 ring-white/20 shrink-0">
            <Building2 className="w-7 h-7 text-sky-300" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-xl font-extrabold text-white tracking-tight">
                {activeBranch.name} — Branch Control Dashboard
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-blue-400" />
                <span>{activeUser.name} (Branch Head)</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              📍 {activeBranch.address || "Branch Terminal"} • Dedicated branch sales, local inventory & cashier reconciliation
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 z-10 flex-wrap">
          <button
            onClick={() => onNavigateTab("billing")}
            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-blue-600/30"
          >
            <ShoppingBag className="w-4 h-4" />
            <span>Open Billing Counter</span>
          </button>
          <button
            onClick={() => onNavigateTab("inventory")}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition flex items-center gap-2"
          >
            <Package className="w-4 h-4 text-sky-400" />
            <span>Branch Inventory</span>
          </button>
        </div>
      </div>

      {/* Branch Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Branch Sales */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Today's Branch Revenue</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-400 font-mono tracking-tight">
            {settings.currencySymbol} {todayBranchRevenue.toLocaleString()}
          </p>
          <span className="text-[11px] text-slate-400 mt-2 block">{branchInvoices.length} Total Branch Invoices</span>
        </div>

        {/* Drawer Cash Collected */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Drawer Cash Balance</span>
            <div className="w-9 h-9 rounded-xl bg-blue-500/15 border border-blue-500/30 flex items-center justify-center text-blue-400">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-blue-400 font-mono tracking-tight">
            {settings.currencySymbol} {todayBranchCash.toLocaleString()}
          </p>
          <span className="text-[11px] text-slate-400 mt-2 block">Available in Branch Drawer</span>
        </div>

        {/* Branch Udhaar / Credit */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Branch Receivables (Udhaar)</span>
            <div className="w-9 h-9 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Receipt className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-amber-400 font-mono tracking-tight">
            {settings.currencySymbol} {todayBranchUdhaar.toLocaleString()}
          </p>
          <span className="text-[11px] text-slate-400 mt-2 block">Pending Local Customer Credit</span>
        </div>

        {/* Low Stock Alerts */}
        <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-xl relative">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Low Stock Items</span>
            <div className="w-9 h-9 rounded-xl bg-rose-500/15 border border-rose-500/30 flex items-center justify-center text-rose-400">
              <AlertTriangle className="w-5 h-5" />
            </div>
          </div>
          <p className="text-2xl font-black text-rose-400 font-mono tracking-tight">
            {branchLowStockItems.length} Products
          </p>
          <span className="text-[11px] text-slate-400 mt-2 block">Needs Refill from HQ</span>
        </div>
      </div>

      {/* Main Content Grid: Stock Refill Request & Recent Branch Invoices */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Branch Stock & HQ Refill Request */}
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-extrabold text-slate-100 text-sm flex items-center gap-2">
                <Package className="w-4 h-4 text-blue-400" />
                <span>HQ Stock Refill Desk</span>
              </h3>
              <p className="text-[11px] text-slate-400">Request PPRC/PVC pipe fittings directly from Main HQ</p>
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
            <span className="text-xs font-bold text-slate-300 block">
              Low Stock Items in {activeBranch.name}:
            </span>

            {branchLowStockItems.length === 0 ? (
              <p className="text-xs text-emerald-400 font-semibold py-2">
                ✅ All PPRC/PVC stock levels are healthy in this branch!
              </p>
            ) : (
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {branchLowStockItems.slice(0, 5).map((item) => (
                  <div key={item.id} className="flex items-center justify-between text-xs bg-slate-900 p-2 rounded-xl border border-slate-800">
                    <span className="font-medium text-slate-200 truncate max-w-[150px]">{item.name}</span>
                    <span className="font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded-md">
                      {item.stock} left
                    </span>
                  </div>
                ))}
              </div>
            )}

            <button
              onClick={handleRequestHQRefill}
              disabled={stockRefillRequested}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30"
            >
              {stockRefillRequested ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                  <span>Refill Request Sent to HQ!</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Send Stock Dispatch Request to Main HQ</span>
                </>
              )}
            </button>
          </div>

          {/* Quick Contact HQ */}
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <PhoneCall className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="font-bold text-slate-200 block">Main HQ Helpline</span>
                <span className="text-[10px] text-slate-400 font-mono">0300-5861463</span>
              </div>
            </div>
            <button
              onClick={() => onNavigateTab("whatsapp_hub")}
              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold text-[10px]"
            >
              WhatsApp HQ
            </button>
          </div>
        </div>

        {/* Right Column: Recent Branch Invoices */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-2xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-extrabold text-slate-100 text-sm flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-400" />
                <span>Recent Invoices Issued at {activeBranch.name}</span>
              </h3>
              <p className="text-[11px] text-slate-400">Live sales log generated by cashiers at this branch</p>
            </div>
            <button
              onClick={() => onNavigateTab("reports")}
              className="text-xs text-blue-400 hover:text-blue-300 font-bold flex items-center gap-1"
            >
              <span>View All Reports</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="space-y-2">
            {branchInvoices.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8">
                No invoices generated at this branch today yet. Open Billing Counter to issue receipts!
              </p>
            ) : (
              branchInvoices.slice(0, 6).map((inv) => (
                <div
                  key={inv.id}
                  className="bg-slate-950 border border-slate-800/80 p-3 rounded-2xl flex items-center justify-between hover:border-slate-700 transition text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold">
                      #
                    </div>
                    <div>
                      <span className="font-bold text-slate-100 block font-mono">{inv.invoiceNumber}</span>
                      <span className="text-[10px] text-slate-400">{inv.customerName} • {new Date(inv.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-extrabold text-slate-100 font-mono block">
                      {settings.currencySymbol} {inv.grandTotal.toLocaleString()}
                    </span>
                    <span className={`text-[10px] font-bold ${inv.balanceDue > 0 ? "text-amber-400" : "text-emerald-400"}`}>
                      {inv.balanceDue > 0 ? `Udhaar: ${settings.currencySymbol}${inv.balanceDue}` : "Fully Paid"}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
